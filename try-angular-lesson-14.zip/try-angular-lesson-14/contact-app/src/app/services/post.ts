export const POSTS = [{
  id: 8,
  title: "dolorem dolore est ipsam",
  body: "dignissimos aperiam dolorem qui eum facilis quibusdam animi sint suscipit qui sint possimus cum quaerat magni maiores excepturi ipsam ut commodi dolor voluptatum modi aut vitae"
},
{
  id: 9,
  title: "nesciunt iure omnis dolorem tempora et accusantium",
  body: "consectetur animi nesciunt iure dolore enim quia ad veniam autem ut quam aut nobis et est aut quod aut provident voluptas autem voluptas"
},
{
  id: 10,
  title: "optio molestias id quia eum",
  body: "quo et expedita modi cum officia vel magni doloribus qui repudiandae vero nisi sit quos veniam quod sed accusamus veritatis error"
},
{
  id: 11,
  title: "et ea vero quia laudantium autem",
  body: "delectus reiciendis molestiae occaecati non minima eveniet qui voluptatibus accusamus in eum beatae sit vel qui neque voluptates ut commodi qui incidunt ut animi commodi"
},
{
  id: 12,
  title: "in quibusdam tempore odit est dolorem",
  body: "itaque id aut magnam praesentium quia et ea odit et ea voluptas et sapiente quia nihil amet occaecati quia id voluptatem incidunt ea est distinctio odio"
},
{
  id: 13,
  title: "dolorum ut in voluptas mollitia et saepe quo animi",
  body: "aut dicta possimus sint mollitia voluptas commodi quo doloremque iste corrupti reiciendis voluptatem eius rerum sit cumque quod eligendi laborum minima perferendis recusandae assumenda consectetur porro architecto ipsum ipsam"
},
{
  id: 14,
  title: "voluptatem eligendi optio",
  body: "fuga et accusamus dolorum perferendis illo voluptas non doloremque neque facere ad qui dolorum molestiae beatae sed aut voluptas totam sit illum"
},
{
  id: 15,
  title: "eveniet quod temporibus",
  body: "reprehenderit quos placeat velit minima officia dolores impedit repudiandae molestiae nam voluptas recusandae quis delectus officiis harum fugiat vitae"
}];
